﻿namespace mvc_crud.Models
{
    public class Salary
    {
        public string? EmpCode { get; set; }
        public int SalaryId { get; set; }
        public decimal Salaryy { get; set; }
    }
}
