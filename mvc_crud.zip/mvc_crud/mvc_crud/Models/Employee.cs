﻿namespace mvc_crud.Models
{
    public class Employee
    {
        public string? EmpCode { get; set; }
        public string? EmployeeName { get; set; }
        public string? EmailId { get; set; }
        public DateTime JoiningDate { get; set; }
        public int DepartmentId { get; set; }
        public bool Status { get; set; }
    }
}
