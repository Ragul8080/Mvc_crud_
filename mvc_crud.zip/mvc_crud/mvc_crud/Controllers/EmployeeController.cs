﻿using Microsoft.AspNetCore.Mvc;
using mvc_crud.Models;
using System.Data.SqlClient;
using System.Reflection.Emit;


namespace mvc_crud.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Register(int empCode)
        {
            Employee c = new Employee();

            if (empCode > 0)
            {
                c = GetEmployee(empCode);
            }

            ViewBag.Departments = GetDepartments();

            return View(c);
        }

        [HttpPost]
        public IActionResult Register(Employee employee)
        {
            if (ModelState.IsValid)
            {
                //employee.DepartmentId = 1;
                string query = "insert into T_Employee (EmployeeName, EmailId, DepartmentId) values (@Name, @Email, @DepartmentId)";
                executeQuery(query, employee);
                return RedirectToAction("Index");
            }
            ViewBag.Departments = GetDepartments();
            return View(employee);
        }

        public IActionResult Index()
        {
            return View(GetEmployees());
        }

        //public IActionResult Edit(string empCode)
        //{
            
        //}

        [HttpPost]
        public IActionResult Edit(Employee employee)
        {
            if (ModelState.IsValid)
            {
                string query = "update T_Employee set Name = @Name, Email = @Email, DepartmentId = @DepartmentId where Id = @Id";
                executeQuery(query, employee);
                return RedirectToAction("Index");
            }
            ViewBag.Departments = GetDepartments();
            return View(employee);
        }

        public IActionResult Remove(int empCode)
        {
            string query = "update T_Employee set Status = 0 where EmpCode = @EmpCode";
            removeQuery(query, empCode);
            return RedirectToAction("Index");
        }

        private List<Department> GetDepartments()
        {
            string query = "select * from dbo.T_Department";
            return executeQueryDepartment(query);
        }

        private List<Employee> GetEmployees()
        {
            string query = "select * from T_Employee where Status = 1";
            return executeQueryEmployee(query);
        }

        private Employee GetEmployee(int empCode)
        {
            string query = "select * from T_Employee where EmpCode = @EmpCode";
            return executeQueryEmployee(query, empCode).FirstOrDefault();
        }

        private List<Department> executeQueryDepartment(string query)
        {
            string constring = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=mvc;Integrated Security=True;Connect Timeout=30;Encrypt=False;";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand sqlCommand = new SqlCommand(query, con);
            con.Open();
            SqlDataReader reader = sqlCommand.ExecuteReader();
            List<Department> departments = new List<Department>();
            while (reader.Read())
            {
                Department department = new Department();
                department.DepartmentId = int.Parse(reader["DepartmentId"].ToString());
                department.DepartmentName = reader["DepartmentName"].ToString();
                departments.Add(department);
            }
            con.Close();
            return departments;
        }

        private List<Employee> executeQueryEmployee(string query, int? param = null)
        {
            string constring = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=mvc;Integrated Security=True;Connect Timeout=30;Encrypt=False;";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand sqlCommand = new SqlCommand(query, con);
            if (param != null)
            {
                sqlCommand.Parameters.AddWithValue("@EmpCode", param);
            }
            con.Open();
            SqlDataReader reader = sqlCommand.ExecuteReader();
            List<Employee> employees = new List<Employee>();
            while (reader.Read())
            {
                Employee employee = new Employee();
                employee.EmpCode = reader["EmpCode"].ToString();
                employee.EmployeeName = reader["EmployeeName"].ToString();
                employee.EmailId = reader["EmailId"].ToString();
                employee.DepartmentId = int.Parse(reader["DepartmentId"].ToString());
                employees.Add(employee);
            }
            con.Close();
            return employees;
        }

        private void executeQuery(string query, object param)
        {
            string constring = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=mvc;Integrated Security=True;Connect Timeout=30;Encrypt=False;";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand sqlCommand = new SqlCommand(query, con);
            sqlCommand.Parameters.AddWithValue("@Name", param.GetType().GetProperty("EmployeeName")?.GetValue(param));
            sqlCommand.Parameters.AddWithValue("@Email", param.GetType().GetProperty("EmailId")?.GetValue(param));
            sqlCommand.Parameters.AddWithValue("@DepartmentId", param.GetType().GetProperty("DepartmentId")?.GetValue(param));
            con.Open();
            sqlCommand.ExecuteNonQuery();
            con.Close();
        }

        private void removeQuery(string query, int param)
        {
            string constring = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=mvc;Integrated Security=True;Connect Timeout=30;Encrypt=False;";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand sqlCommand = new SqlCommand(query, con);
            sqlCommand.Parameters.AddWithValue("@EmpCode", param);
            con.Open();
            sqlCommand.ExecuteNonQuery();
            con.Close();
        }
    }
}
